import { useEffect, useRef, useState } from "react";
import { openChat, ProductCard, Rail, SectionHead } from "../components";
import { loadHome, type HomeData, type Site } from "../data";
import { num } from "../format";
import { Link, navigate, useTitle } from "../router";

interface Slide {
  image: string;
  eyebrow: string;
  title: string;
  text: string;
  primary: { to: string; label: string };
  secondary: { to: string; label: string };
  caption: string;
}

function Hero({ slides, video }: { slides: Slide[]; video: HomeData["video"] }) {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const start = useRef<number | null>(null);
  const reduced = typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const n = slides.length;
  const go = (k: number) => setI(((k % n) + n) % n);
  useEffect(() => {
    if (paused || reduced || n < 2) return;
    const t = setTimeout(() => go(i + 1), 7000);
    return () => clearTimeout(t);
  }, [i, paused, n, reduced]);
  if (!n) return null;
  const s = slides[i];
  return (
    <section
      className="hero-carousel"
      aria-roledescription="carousel"
      aria-label="Featured stock"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
      onKeyDown={(e) => {
        if (e.key === "ArrowRight") go(i + 1);
        if (e.key === "ArrowLeft") go(i - 1);
      }}
      onPointerDown={(e) => (start.current = e.clientX)}
      onPointerUp={(e) => {
        if (start.current !== null && Math.abs(e.clientX - start.current) > 50) go(i + (e.clientX < start.current ? 1 : -1));
        start.current = null;
      }}
    >
      <div className="wrap hero-grid" key={i}>
        <div className="hero-copy" aria-live={paused ? "polite" : "off"}>
          <p className="eyebrow eyebrow-gold">{s.eyebrow}</p>
          <h1>{s.title}</h1>
          <p className="lede">{s.text}</p>
          <div className="hero-ctas">
            <Link to={s.primary.to} className="btn btn-dark btn-lg">
              {s.primary.label}
            </Link>
            <Link to={s.secondary.to} className="btn btn-ghost btn-lg">
              {s.secondary.label}
            </Link>
          </div>
        </div>
        <div className="hero-visual">
          {video && i === 0 ? (
            <video className="hero-video" src={video.src} poster={video.poster} muted playsInline loop autoPlay={!reduced} />
          ) : (
            <div className="hero-photo">
              <img src={s.image} alt={s.caption} referrerPolicy="no-referrer" draggable={false} />
            </div>
          )}
          <p className="hero-caption">{s.caption}</p>
        </div>
      </div>
      {n > 1 && (
        <div className="wrap hero-controls">
          <div className="hero-dots" role="tablist" aria-label="Choose a slide">
            {slides.map((sl, k) => (
              <button key={k} role="tab" aria-selected={k === i} aria-label={`Slide ${k + 1}: ${sl.eyebrow}`} className={k === i ? "on" : undefined} onClick={() => go(k)} />
            ))}
          </div>
          <div className="hero-arrows">
            <button onClick={() => go(i - 1)} aria-label="Previous slide">
              ‹
            </button>
            <button onClick={() => go(i + 1)} aria-label="Next slide">
              ›
            </button>
          </div>
        </div>
      )}
    </section>
  );
}

export default function Home({ site }: { site: Site }) {
  useTitle(`${site.company} · Wholesale stock for resellers`);
  const [home, setHome] = useState<HomeData | null>(null);
  const [q, setQ] = useState("");
  useEffect(() => {
    loadHome().then(setHome, () => setHome({ departments: [], featured: [], recent: [], countries: {}, hero: [], video: null }));
  }, []);
  const total = site.countries.reduce((a, c) => a + c.count, 0);
  const byslug = Object.fromEntries(site.countries.map((c) => [c.slug, c]));
  const slides: Slide[] = (home?.hero ?? []).map((h) => {
    const c = byslug[h.country ?? h.slug];
    return h.kind === "country"
      ? {
          image: h.image,
          eyebrow: `${byslug[h.slug]?.name} stock`,
          title: `${num(byslug[h.slug]?.count ?? 0)} products, ready for your store.`,
          text: `Wholesale prices per unit in ${byslug[h.slug]?.currency}. Choose, verify and send an order request; our team confirms stock and price before you pay.`,
          primary: { to: `/${h.slug}`, label: `Shop ${byslug[h.slug]?.name}` },
          secondary: { to: `/${h.slug}/${h.product}`, label: "View this product" },
          caption: h.product_name,
        }
      : {
          image: h.image,
          eyebrow: h.name ?? "Category",
          title: `${h.name}, sourced for resellers.`,
          text: "Browse every country in one place, compare prices and open each product's reference before you list it.",
          primary: { to: `/categories/${h.slug}`, label: `Shop ${h.name}` },
          secondary: { to: `/${c?.slug}/${h.product}`, label: "View this product" },
          caption: h.product_name,
        };
  });

  return (
    <main className="home">
      {home && slides.length > 0 ? (
        <Hero slides={slides} video={home.video} />
      ) : (
        <section className="hero-carousel hero-placeholder">
          <div className="wrap">
            <h1>Wholesale stock for resellers.</h1>
          </div>
        </section>
      )}

      <section className="wrap search-band">
        <form
          className="hero-search"
          role="search"
          onSubmit={(e) => {
            e.preventDefault();
            if (q.trim()) navigate(`/products?q=${encodeURIComponent(q.trim())}`);
          }}
        >
          <svg width="18" height="18" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <circle cx="7" cy="7" r="4.6" stroke="currentColor" strokeWidth="1.5" />
            <path d="m10.5 10.5 3.2 3.2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Search ${num(total)} products by name or reference`} aria-label="Search products" />
          <button className="btn btn-dark" type="submit">
            Search
          </button>
        </form>
      </section>

      <section className="wrap section">
        <SectionHead eyebrow="Shop by country" title="Five catalogues, one way of ordering." link={{ to: "/countries", label: "Compare countries" }} />
        <div className="country-showcase">
          {site.countries.map((c) => (
            <Link key={c.slug} to={`/${c.slug}`} className="country-tile">
              <div className="country-collage">
                {(home?.countries[c.slug] ?? []).slice(0, 3).map((img, k) => (
                  <img key={k} src={img} alt="" loading="lazy" referrerPolicy="no-referrer" />
                ))}
              </div>
              <div className="country-tile-body">
                <span className="country-code">{c.currency}</span>
                <span className="country-name">{c.name}</span>
                <span className="muted small">
                  {num(c.count)} products · {num(c.available)} available now
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {home && home.departments.length > 0 && (
        <section className="wrap section">
          <SectionHead eyebrow="Shop by category" title="Browse by what you sell." link={{ to: "/categories", label: "All categories" }} />
          <div className="dept-grid">
            {home.departments.slice(0, 8).map((d) => (
              <Link key={d.slug} to={`/categories/${d.slug}`} className="dept-card">
                <div className="dept-img">{d.image && <img src={d.image} alt="" loading="lazy" referrerPolicy="no-referrer" />}</div>
                <div className="dept-body">
                  <span className="dept-name">{d.name}</span>
                  <span className="muted small">{num(d.count)} products</span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {home && home.featured.length > 0 && (
        <section className="wrap section">
          <SectionHead eyebrow="Featured" title="A selection from every catalogue." link={{ to: "/products", label: "All products" }} />
          <Rail label="featured products">
            {home.featured.map(({ slug, product }) => (
              <div className="rail-item" key={product.code}>
                <ProductCard product={product} country={byslug[slug]} showCountry />
              </div>
            ))}
          </Rail>
        </section>
      )}

      {home && home.recent.length > 0 && (
        <section className="wrap section">
          <SectionHead eyebrow="New in the catalogue" title="Recently added stock." link={{ to: "/products?sort=new", label: "See the newest" }} />
          <Rail label="recently added products">
            {home.recent.map(({ slug, product }) => (
              <div className="rail-item" key={product.code}>
                <ProductCard product={product} country={byslug[slug]} showCountry />
              </div>
            ))}
          </Rail>
        </section>
      )}

      <section className="wrap section">
        <SectionHead eyebrow="How Ravisn works" title="From product to parcel in four steps." link={{ to: "/how-it-works", label: "The full process" }} />
        <ol className="steps-luxe">
          {[
            ["Choose", "Find products by country or category. Open each product's reference to check the size, variation and photos."],
            ["Request", "Add products to your order, enter the recipient's details and send the request. Nothing is charged."],
            ["Confirm", "Our team confirms stock, price and shipping with you, then sends payment details."],
            ["Ship", "Send your own prepaid label, or ask Ravisn to arrange one. Tracking appears on your order page once it is dispatched."],
          ].map(([h, t], k) => (
            <li key={h}>
              <span className="step-index">{String(k + 1).padStart(2, "0")}</span>
              <h3>{h}</h3>
              <p>{t}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="wrap section why">
        <SectionHead eyebrow="Why resellers work with Ravisn" title="Clear prices, confirmed orders, your shipping." />
        <div className="why-grid">
          {[
            [`${num(total)} products`, `Wholesale catalogues for the ${site.countries.map((c) => c.name).join(", ").replace(/, ([^,]*)$/, " and $1")}.`],
            ["Prices per unit", "Every price is shown per unit in the catalogue's own currency, with options such as single or pack where they exist."],
            ["Nothing is charged online", "You send an order request. Our team confirms stock, price and shipping before asking for payment."],
            ["Your shipping, your way", "Use your own prepaid labels, or request a separately confirmed shipping quote from Ravisn."],
            ["Permanent references", "Each product keeps its Ravisn reference, so your listings and repeat orders stay consistent."],
            ["People behind the catalogue", "The Ravisn team reviews every order and answers in the chat when available."],
          ].map(([h, t]) => (
            <div key={h} className="why-item">
              <h3>{h}</h3>
              <p>{t}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="wrap section ship-band">
        <div>
          <p className="eyebrow eyebrow-gold">Shipping and fulfilment</p>
          <h2>Shipping is your choice, and your cost.</h2>
          <p>Product prices do not include shipping. You can charge your customer for shipping or include it in your own selling price. Upload your own prepaid label to your order, or ask Ravisn for a shipping quote.</p>
        </div>
        <div className="ship-band-actions">
          <Link to="/shipping" className="btn btn-light">
            Shipping and labels
          </Link>
          <Link to="/track" className="btn btn-ghost-light">
            Track an order
          </Link>
        </div>
      </section>

      <section className="wrap section faq-preview">
        <SectionHead eyebrow="Questions" title="Good to know before your first order." link={{ to: "/faq", label: "All FAQs" }} />
        <div className="faq">
          {[
            ["Is my order paid when I send it?", "No. Sending an order is a request. Our team confirms stock, price and shipping with you first, then sends payment details."],
            ["Who pays for shipping?", "You do. Shipping is separate from product prices: send your own prepaid label, or ask Ravisn for a quote."],
            ["Are the photos exact?", "Photos are a reference. Packaging, colours and presentation may vary, so open the product reference and check the size, variation and quantity."],
            ["Can I order from several countries?", "Each order holds products from one country's catalogue. Send a separate order for each country."],
          ].map(([q2, a]) => (
            <details key={q2}>
              <summary>{q2}</summary>
              <div className="faq-a">{a}</div>
            </details>
          ))}
        </div>
      </section>

      <section className="wrap section closing">
        <h2>Ready to stock your store?</h2>
        <p>Browse the catalogue, or tell us what you are looking for and we will help you find it.</p>
        <div className="row-gap center">
          <Link to="/products" className="btn btn-gold btn-lg">
            Browse all products
          </Link>
          <button className="btn btn-ghost-light btn-lg" onClick={() => openChat()}>
            Ask the Ravisn Assistant
          </button>
        </div>
      </section>
    </main>
  );
}
